﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Template
{
    class Shape
    {
        protected int width;

        public int Height
        {
            get { return width }
        }


        public Shape(int height, int width)
        {
            this.height = height;
            this.width = width;
        }
    }
}
